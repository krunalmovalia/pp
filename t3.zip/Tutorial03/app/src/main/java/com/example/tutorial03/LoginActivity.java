package com.example.tutorial03;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {


    EditText emailID, password;
    TextView txtRegistration;
    String email = "admin@gmail.com", pass = "admin";
    AppCompatButton btnLogin;
    public static final String PREFS_NAME = "LoginPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Toast.makeText(this, "Krunal Movalia 21SOECE13085", Toast.LENGTH_LONG).show();

        emailID = findViewById(R.id.email);
        password = findViewById(R.id.pwd);
        btnLogin = findViewById(R.id.btnLogin);
        txtRegistration = findViewById(R.id.txtRegistration);

        txtRegistration.setOnClickListener(v -> {
            Intent in = new Intent(getApplicationContext(), RegistrationActivity.class);
            startActivity(in);
        });

        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        if (settings.getString("logged", "").toString().equals("logged")) {
            Intent intent = new Intent(LoginActivity.this, WelcomeActivity.class);
            intent.putExtra("email1",emailID.getText().toString());
            startActivity(intent);
        }

        btnLogin.setOnClickListener(v -> {
            if (emailID.getText().toString().trim().isEmpty()){
                emailID.setError("Please enter your Email");
                emailID.requestFocus();
            }
            else if (!isValidEmail(emailID.getText().toString()) )
            {
                emailID.setError("Please enter valid Email");
                emailID.requestFocus();
            }
            else if (password.getText().toString().trim().isEmpty()){
                password.setError("Please enter your Password");
                password.requestFocus();
            }
            else if (emailID.getText().toString().equals(email) && password.getText().toString().equals(pass))
            {
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("logged", "logged");
                editor.apply();

                Intent i = new Intent(getApplicationContext(), WelcomeActivity.class);
                i.putExtra("email",emailID.getText().toString());
                startActivity(i);
                Toast.makeText(this, "Login Successfully !", Toast.LENGTH_SHORT).show();
            }

            else
            {
                Toast.makeText(this, "Invalid Email or Password.", Toast.LENGTH_SHORT).show();
            }



        });


    }
    private boolean isValidEmail(String Email){
        String Email_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern pattern = Pattern.compile(Email_PATTERN);
        Matcher matcher = pattern.matcher(Email);
        return matcher.matches();
    }
}