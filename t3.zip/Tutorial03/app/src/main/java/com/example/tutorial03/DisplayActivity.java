package com.example.tutorial03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);


        Intent intent=getIntent();
        TextView fname =(TextView)findViewById(R.id.dFname);
        fname.setText(intent.getStringExtra("fname"));
        TextView lname =(TextView)findViewById(R.id.dLname);
        lname.setText(intent.getStringExtra("lname"));
        TextView email =(TextView)findViewById(R.id.email);
        email.setText(intent.getStringExtra("email"));
        TextView pass =(TextView)findViewById(R.id.password);
        pass.setText(intent.getStringExtra("pass"));
        TextView gender=(TextView)findViewById(R.id.gender);
        gender.setText(intent.getStringExtra("radioSex"));
        TextView city=(TextView)findViewById(R.id.city);
        city.setText(intent.getStringExtra("city"));
        TextView status=(TextView)findViewById(R.id.status);
        status.setText(intent.getStringExtra("status"));


    }
}